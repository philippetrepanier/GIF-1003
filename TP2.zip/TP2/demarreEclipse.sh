#!/bin/sh
eclipse -data .
